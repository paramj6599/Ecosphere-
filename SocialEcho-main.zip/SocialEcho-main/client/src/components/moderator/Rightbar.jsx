import ModeratorProfile from "./ModeratorProfile";

const Rightbar = () => {
  return (
    <div className="rightbar">
      <ModeratorProfile />
    </div>
  );
};

export default Rightbar;
