import { BarLoader } from "react-spinners";

const CommonLoading = () => {
  return <BarLoader color="#008cff" height={5} width={100} />;
};

export default CommonLoading;
